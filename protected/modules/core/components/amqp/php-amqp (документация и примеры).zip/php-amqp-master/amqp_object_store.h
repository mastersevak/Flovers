#ifndef AMQP_OBJECT_STORE_PATCH_H
#define AMQP_OBJECT_STORE_PATCH_H
void *amqp_object_store_get_valid_object(const zval *zobject TSRMLS_DC);
#endif
