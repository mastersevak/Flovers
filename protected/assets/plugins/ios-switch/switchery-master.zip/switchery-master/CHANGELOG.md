
0.3.6 / 2014-01-04
==================

  * Generate new standalone file
  * Refactor code
  * Use event constructors to create onchange and click events
  * Updated standalone to dist in bower.json
  * Required files
  * Add development info

0.3.5 / 2013-12-31
==================

  * Proper checkbox value with onchange event

0.3.4 / 2013-12-31
==================

  * Merge ni-c:master
  * Refactor onchange

0.3.3 / 2013-12-28
==================

  * Merge pull request from tenbits:patch-1
  * Leave first line empty
  * Undefined option's property
  * Update Readme
  * Update standalone
  * Changelog
  * Standalone -> dist, update Readme, add changelog

0.3.2 / 2013-12-27
==================

  * Standalone -> dist, update Readme, add changelog
  * Merge pull request from vesln:min
  * Add minified versions
  * Minify CSS & JS
  * Fix the standalone build & improve Makefile
  * Ignore node_modules
  * Add package.json
  * Disabled opacity option
  * Disabled opacity option
  * Insert switch after target element
  * Require Transitionize